// BELLE CHOSE HOME DECOR: edit this file to change contacts, branches, social links and products.
// Each product line is: [category, "Name", "image path", featured on home page (1) or not (0)]
window.SITE = {
  name: "Belle Chose Home Decor",
  wa: "2349131321559", // main WhatsApp number, digits only with country code
  logo: "images/logo.png", hero: "images/hero.jpg", about: "images/about.jpg",
  social: [["Instagram", "https://instagram.com/bellechose_homedecor"], ["TikTok", "https://www.tiktok.com/@bellechose_homedecor"], ["Facebook", "https://www.facebook.com/search/top?q=Belle%20Chose%20Home%20Decor"], ["Threads", "https://www.threads.net/@bellechose_homedecor"]],
  branches: [
  {
    "n": "Wuse 2 Branch",
    "tag": "Main store",
    "ad": "Berger Paint Plaza, Shop GF4C &amp; GF2A, 6 Alexandria Crescent, Behind Banex, Wuse 2, Abuja",
    "hr": "Mon – Sat · about 9:00am – 7/8:00pm",
    "ph": [
      [
        "+234 913 132 1559",
        "2349131321559"
      ],
      [
        "+234 814 000 0399",
        "2348140000399"
      ]
    ],
    "q": "Belle Chose Home Decor Wuse 2 Abuja"
  },
  {
    "n": "Asokoro Branch",
    "tag": "Open Sundays",
    "ad": "Westwood Plaza, Shop GF4, 4 Maitama Sule Street, Next to Keystone Bank, A.Y.A, Asokoro, Abuja",
    "hr": "Mon – Sat · about 9:00am – 7/8:00pm<br>Sunday · 1:00pm – 7:00pm",
    "ph": [
      [
        "+234 707 059 9932",
        "2347070599932"
      ],
      [
        "+234 707 855 0890",
        "2347078550890"
      ]
    ],
    "q": "Belle Chose Home Decor Asokoro Abuja"
  }
],
  cats: {
  "bedroom": "Bedroom",
  "scent": "Scent & Fragrance",
  "luxury": "Luxury Diffusers",
  "bath": "Bath & Body",
  "kitchen": "Kitchen & Dining",
  "decor": "Living Room & Decor",
  "rugs": "Rugs & Doormats",
  "cushions": "Cushions & Throws",
  "sculptures": "Sculptures & Ornaments",
  "bins": "Bins & Baskets",
  "household": "Laundry & Household",
  "gifts": "Gifts & Extras"
},
  items: [
    // ---- Bedroom ----
    ["bedroom", "Geometric cotton duvet set", "images/bedroom/geometric-cotton-duvet-set.jpg", 0],
    ["bedroom", "Plum petal duvet set", "images/bedroom/plum-petal-duvet-set.jpg", 1],
    ["bedroom", "Green geometric bedding", "images/bedroom/green-geometric-bedding.jpg", 0],
    ["bedroom", "Abstract linework bedding", "images/bedroom/abstract-linework-bedding.jpg", 0],
    // ---- Scent & Fragrance ----
    ["scent", "Midnight Oud scented candles", "images/scent/midnight-oud-scented-candles.jpg", 1],
    ["scent", "Navy Cashmere candle", "images/scent/navy-cashmere-candle.jpg", 0],
    ["scent", "Sculptural candles", "images/scent/sculptural-candles.jpg", 0],
    ["scent", "Pastel jar candles", "images/scent/pastel-jar-candles.jpg", 0],
    ["scent", "Lavender reed diffuser", "images/scent/lavender-reed-diffuser.jpg", 1],
    ["scent", "Reed diffuser trio", "images/scent/reed-diffuser-trio.jpg", 0],
    ["scent", "Boutique diffusers & room spray", "images/scent/boutique-diffusers-room-spray.jpg", 0],
    ["scent", "Dr. Vranjes diffusers", "images/scent/dr-vranjes-diffusers.jpg", 0],
    ["scent", "Rose home fragrance oil", "images/scent/rose-home-fragrance-oil.jpg", 0],
    ["scent", "Lilac & lavender fragrance oil", "images/scent/lilac-lavender-fragrance-oil.jpg", 0],
    ["scent", "Hanging car fragrance", "images/scent/hanging-car-fragrance.jpg", 0],
    ["scent", "Concentrated room sprays", "images/scent/concentrated-room-sprays.jpg", 0],
    ["scent", "Room mist sprays", "images/scent/room-mist-sprays.jpg", 0],
    ["scent", "Seasonal room sprays", "images/scent/seasonal-room-sprays.jpg", 0],
    // ---- Luxury Diffusers ----
    ["luxury", "Locherber Milano Café Satin", "images/luxury/locherber-milano-caf-satin.jpg", 1],
    ["luxury", "Locherber Café Satin trio", "images/luxury/locherber-caf-satin-trio.jpg", 0],
    ["luxury", "Locherber diffuser", "images/luxury/locherber-diffuser.jpg", 0],
    ["luxury", "Locherber on stone", "images/luxury/locherber-on-stone.jpg", 0],
    ["luxury", "Locherber styled with gold", "images/luxury/locherber-styled-with-gold.jpg", 0],
    ["luxury", "Luxury reed diffusers", "images/luxury/luxury-reed-diffusers.jpg", 0],
    ["luxury", "Boutique glass diffusers", "images/luxury/boutique-glass-diffusers.jpg", 0],
    ["luxury", "Gold diffuser & candle set", "images/luxury/gold-diffuser-candle-set.jpg", 0],
    ["luxury", "Golden amber diffuser", "images/luxury/golden-amber-diffuser.jpg", 1],
    ["luxury", "Dr. Vranjes Calvados diffuser", "images/luxury/dr-vranjes-calvados-diffuser.jpg", 0],
    ["luxury", "Artisan glass diffusers", "images/luxury/artisan-glass-diffusers.jpg", 0],
    ["luxury", "Artisan glass diffuser & oil", "images/luxury/artisan-glass-diffuser-oil.jpg", 0],
    ["luxury", "Silver pedestal diffuser", "images/luxury/silver-pedestal-diffuser.jpg", 0],
    // ---- Bath & Body ----
    ["bath", "Rose, Poppy & Vanilla hand wash", "images/bath/rose-poppy-vanilla-hand-wash.jpg", 0],
    ["bath", "Coconut & Watermelon hand wash", "images/bath/coconut-watermelon-hand-wash.jpg", 0],
    ["bath", "Bath & body care set", "images/bath/bath-body-care-set.jpg", 0],
    ["bath", "Bath & body care gift bag", "images/bath/bath-body-care-gift-bag.jpg", 0],
    // ---- Kitchen & Dining ----
    ["kitchen", "Purple & gold cookware set", "images/kitchen/purple-gold-cookware-set.jpg", 1],
    ["kitchen", "Rose-pink 60-piece cookware", "images/kitchen/rose-pink-60-piece-cookware.jpg", 0],
    ["kitchen", "Taupe & gold cookware", "images/kitchen/taupe-gold-cookware.jpg", 0],
    ["kitchen", "Teal & gold dinner set", "images/kitchen/teal-gold-dinner-set.jpg", 0],
    ["kitchen", "Matte black dinner set", "images/kitchen/matte-black-dinner-set.jpg", 0],
    ["kitchen", "Green & gold cutlery set", "images/kitchen/green-gold-cutlery-set.jpg", 0],
    ["kitchen", "Wooden utensil set", "images/kitchen/wooden-utensil-set.jpg", 0],
    ["kitchen", "Rose gold knife set", "images/kitchen/rose-gold-knife-set.jpg", 0],
    ["kitchen", "Marble thermos flasks", "images/kitchen/marble-thermos-flasks.jpg", 0],
    ["kitchen", "Gold lattice thermos", "images/kitchen/gold-lattice-thermos.jpg", 0],
    ["kitchen", "Glass canisters", "images/kitchen/glass-canisters.jpg", 0],
    ["kitchen", "Spice carousel", "images/kitchen/spice-carousel.jpg", 0],
    ["kitchen", "Blender set", "images/kitchen/blender-set.jpg", 0],
    ["kitchen", "Food processor", "images/kitchen/food-processor.jpg", 0],
    // ---- Living Room & Decor ----
    ["decor", "Black photo frame", "images/decor/black-photo-frame.jpg", 0],
    ["decor", "Marble photo frame", "images/decor/marble-photo-frame.jpg", 0],
    ["decor", "Arch marble frame", "images/decor/arch-marble-frame.jpg", 0],
    ["decor", "Wooden vase", "images/decor/wooden-vase.jpg", 0],
    ["decor", "Black ceramic vase", "images/decor/black-ceramic-vase.jpg", 0],
    ["decor", "Marble bookend", "images/decor/marble-bookend.jpg", 0],
    ["decor", "Black & gold wall clock", "images/decor/black-gold-wall-clock.jpg", 1],
    ["decor", "Round gold mirror", "images/decor/round-gold-mirror.jpg", 0],
    ["decor", "Floral arrangement", "images/decor/floral-arrangement.jpg", 0],
    // ---- Rugs & Doormats ----
    ["rugs", "Green & cream rug", "images/rugs/green-cream-rug.jpg", 0],
    ["rugs", "Black & cream swirl rug", "images/rugs/black-cream-swirl-rug.jpg", 1],
    ["rugs", "Wavy hallway runner", "images/rugs/wavy-hallway-runner.jpg", 0],
    ["rugs", "Concentric colour rug", "images/rugs/concentric-colour-rug.jpg", 0],
    ["rugs", "Welcome doormat", "images/rugs/welcome-doormat.jpg", 0],
    ["rugs", "Hello doormat", "images/rugs/hello-doormat.jpg", 0],
    ["rugs", "Patterned rug rolls", "images/rugs/patterned-rug-rolls.jpg", 0],
    ["rugs", "Luxury shag & woven rugs", "images/rugs/luxury-shag-woven-rugs.jpg", 0],
    ["rugs", "Floral & traditional rugs", "images/rugs/floral-traditional-rugs.jpg", 0],
    ["rugs", "Designer rug collection", "images/rugs/designer-rug-collection.jpg", 0],
    ["rugs", "Plush shaggy rugs", "images/rugs/plush-shaggy-rugs.jpg", 0],
    ["rugs", "Neutral textured rugs", "images/rugs/neutral-textured-rugs.jpg", 0],
    // ---- Cushions & Throws ----
    ["cushions", "Statement cushion collection", "images/cushions/statement-cushion-collection.jpg", 0],
    ["cushions", "Leather & geometric cushions", "images/cushions/leather-geometric-cushions.jpg", 0],
    ["cushions", "Plush faux-fur cushions", "images/cushions/plush-faux-fur-cushions.jpg", 0],
    ["cushions", "Terracotta cushions & throw", "images/cushions/terracotta-cushions-throw.jpg", 1],
    ["cushions", "Soft plush cushions", "images/cushions/soft-plush-cushions.jpg", 0],
    ["cushions", "Mustard cushions & throw", "images/cushions/mustard-cushions-throw.jpg", 0],
    ["cushions", "Textured cushion display", "images/cushions/textured-cushion-display.jpg", 0],
    ["cushions", "Grey geometric cushions", "images/cushions/grey-geometric-cushions.jpg", 0],
    ["cushions", "Floral & velvet cushions", "images/cushions/floral-velvet-cushions.jpg", 0],
    // ---- Sculptures & Ornaments ----
    ["sculptures", "Crystal crane sculptures", "images/sculptures/crystal-crane-sculptures.jpg", 1],
    ["sculptures", "Hand & face sculpture", "images/sculptures/hand-face-sculpture.jpg", 0],
    ["sculptures", "Gold face sculptures", "images/sculptures/gold-face-sculptures.jpg", 0],
    ["sculptures", "Elephant herd sculpture", "images/sculptures/elephant-herd-sculpture.jpg", 0],
    ["sculptures", "Sparkle cat figurine", "images/sculptures/sparkle-cat-figurine.jpg", 0],
    ["sculptures", "White & gold abstract set", "images/sculptures/white-gold-abstract-set.jpg", 0],
    ["sculptures", "Moon reader sculpture", "images/sculptures/moon-reader-sculpture.jpg", 1],
    ["sculptures", "Gold cylinder ornaments", "images/sculptures/gold-cylinder-ornaments.jpg", 0],
    ["sculptures", "Silence sculpture", "images/sculptures/silence-sculpture.jpg", 0],
    ["sculptures", "Crystal sphere stands", "images/sculptures/crystal-sphere-stands.jpg", 0],
    ["sculptures", "Gold deer set", "images/sculptures/gold-deer-set.jpg", 0],
    ["sculptures", "Navy & gold ornaments", "images/sculptures/navy-gold-ornaments.jpg", 0],
    // ---- Bins & Baskets ----
    ["bins", "Matte pedal bins", "images/bins/matte-pedal-bins.jpg", 0],
    ["bins", "Ribbed pedal bins", "images/bins/ribbed-pedal-bins.jpg", 0],
    ["bins", "Sensor bin", "images/bins/sensor-bin.jpg", 0],
    ["bins", "Woven-look laundry basket", "images/bins/woven-look-laundry-basket.jpg", 0],
    ["bins", "Lidded laundry baskets", "images/bins/lidded-laundry-baskets.jpg", 0],
    ["bins", "Slim lidded baskets", "images/bins/slim-lidded-baskets.jpg", 0],
    ["bins", "Rattan laundry basket", "images/bins/rattan-laundry-basket.jpg", 0],
    ["bins", "Mesh laundry baskets", "images/bins/mesh-laundry-baskets.jpg", 0],
    ["bins", "Four-drawer storage tower", "images/bins/four-drawer-storage-tower.jpg", 0],
    ["bins", "Lidded storage baskets", "images/bins/lidded-storage-baskets.jpg", 0],
    // ---- Laundry & Household ----
    ["household", "Astonish bathroom cleaner", "images/household/astonish-bathroom-cleaner.jpg", 0],
    ["household", "Multipurpose cleaner with bleach", "images/household/multipurpose-cleaner-with-bleach.jpg", 0],
    ["household", "Window & glass cleaner", "images/household/window-glass-cleaner.jpg", 0],
    ["household", "Lysol all-purpose cleaner", "images/household/lysol-all-purpose-cleaner.jpg", 0],
    ["household", "In-wash scent boosters", "images/household/in-wash-scent-boosters.jpg", 0],
    ["household", "Fabric softener", "images/household/fabric-softener.jpg", 0],
    ["household", "Fabric care detergents", "images/household/fabric-care-detergents.jpg", 0],
    ["household", "Concentrated fabric detergent", "images/household/concentrated-fabric-detergent.jpg", 0],
    // ---- Gifts & Extras ----
    ["gifts", "Aromatherapy hand crème set", "images/gifts/aromatherapy-hand-cr-me-set.jpg", 0],
    ["gifts", "Mini hand crème library", "images/gifts/mini-hand-cr-me-library.jpg", 0],
    ["gifts", "Hand cream gift set", "images/gifts/hand-cream-gift-set.jpg", 0],
    ["gifts", "Wildflower hand cream trio", "images/gifts/wildflower-hand-cream-trio.jpg", 0],
    ["gifts", "Grooming beard kit", "images/gifts/grooming-beard-kit.jpg", 0],
    ["gifts", "Slippers & grooming gift set", "images/gifts/slippers-grooming-gift-set.jpg", 0],
  ]
};
