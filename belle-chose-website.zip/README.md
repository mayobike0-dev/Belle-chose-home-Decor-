# Belle Chose Home Decor website

A fast static website (no database, no server). Works on GitHub Pages as it is.

## Put it online with GitHub Pages (free)
1. Create a free account at github.com, then tap **New repository**. Name it `belle-chose-website` and keep it **Public**.
2. On a computer, unzip `belle-chose-part-1.zip` and `belle-chose-part-2.zip` into two folders. GitHub accepts at most 100 files per upload, so upload twice: on the repository page tap **Add file > Upload files**, drag in everything inside the part-1 folder, wait for it to finish, then tap **Commit changes**. Repeat the same with everything inside the part-2 folder.
3. Go to **Settings > Pages**. Under Build and deployment choose **Deploy from a branch**, pick the `main` branch and `/ (root)`, then **Save**.
4. After one or two minutes your site is live at `https://YOUR-USERNAME.github.io/belle-chose-website/`.

## Changing things later (no domain needed)
- **Phone numbers, hours, addresses, social links, products:** open `data/site.js` on GitHub, tap the pencil icon, edit, and **Commit changes**. The site updates in about a minute.
- **Add a product:** upload the photo into the matching folder inside `images/`, then add one line in `data/site.js`, for example: `["rugs","Name of the piece","images/rugs/my-photo.jpg",0],`
- **Remove a product:** delete its line in `data/site.js`.
- **Colours and layout:** `css/styles.css`. Page logic: `js/app.js`.
- You can always bring this zip back to Claude to make bigger changes.

## When you buy a domain
In **Settings > Pages > Custom domain**, type the domain and save. GitHub then shows the DNS records to add at the domain provider. Enable **Enforce HTTPS** once it appears.
